/* @license GPL-2.0-or-later https://www.drupal.org/licensing/faq */
jQuery(document).ready(function($){$('.autoplay').slick({dots:true,slidesToShow:3,slidesToScroll:1,autoplay:true,autoplaySpeed:2000,infinite:true,centerMode:true,centerPadding:'0px',arrows:false});});;
jQuery(document).ready(function($){$('.gallery').slick({dots:true,slidesToShow:1,slidesToScroll:1,autoplay:true,autoplaySpeed:2000,infinite:true,arrows:false});});;
jQuery(document).ready(function($){$('.shortsvideo').slick({dots:true,slidesToShow:3,slidesToScroll:1,autoplay:true,autoplaySpeed:2000,infinite:true,arrows:true});});;
jQuery(document).ready(function($){$('.condition').slick({dots:true,slidesToShow:1,slidesToScroll:1,autoplay:true,autoplaySpeed:2000,infinite:true,arrows:true});});;
